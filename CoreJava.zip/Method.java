class Method 
{
	static void m1(){
		System.out.println("m1");
	}
	public static void main(String []mn){
	System.out.println("M2");
	m1();
	}
	public static void main(String[] vishal) 
	{
		System.out.println("Hello ");
		
		
	}
}
