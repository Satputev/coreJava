class MethodOrd 
{
	static void add(int a,int b){
		System.out.println("Two int addition (a+b) is:"+(a+b));
	}
	static void add(int a,int b,int c){
		System.out.println("Three int addition (a+b+c) is:"+(a+b+c));
	}
	static void add(float a,float b){
		System.out.println("Two float addition (a+b) is:"+(a+b));
	}
	static void add(float a,float b,float c){
		System.out.println("Three float addition(a+b+c) is:"+(a+b+c));
	}
	public static void main(String[] args) 
	{
		System.out.println("Main");
		add(10,20);//Two int addition (a+b) is:30

		add(10,20,30);//Three int addition (a+b+c) is:60

		add(10f,20f);//Two float addition (a+b) is:30.0

		add(10f,20f,30f);//Three float addition(a+b+c) is:60.0

	}
}
