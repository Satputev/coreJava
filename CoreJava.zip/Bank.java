class Bank 
{

static void BankDetail(){
	System.out.println("bankDetails");
}

public static void main(String[]args){
	BankDetail();
Customer.createAccount();//private class method
Customer.main(new String[0]);//private class main method
Transection.trsDetails();//public class method
Account.savingAccount();//In Transcection Account class method
Bank.BankDetail();//itself method
}
}