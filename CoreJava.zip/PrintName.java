class PrintName 
{
	public static void main(String[] args) 
	{
		System.out.println("H");
		System.out.println("\ta");
		System.out.println("\t\tr");
		System.out.println("\t\t\ti");
	}
}
