class MainOver 
{
	public static void main(String[] args) 
	{
		System.out.println("Default Main1");//java MainOver //Default Main1
	}
}
class MainOve 
{
	public static void main(String[] args) 
	{
		System.out.println("Default Main2");//java MainOve //Default Main2
	}
}
class MainOv 
{
	public static void main(String[] args) 
	{
		System.out.println("Default Main3");//java MainOv //Default Main3
	}
}
class MainO
{
	public static void main(String[] args) 
	{
		System.out.println("Default Main4");//java MainO //Default Main4
	}
}
