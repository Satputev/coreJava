class Accnt  
{
	String Aname;
	long Ano;
	String Address;
	double Balance;
}
