class Bank1 
{
	public static void main(String[] args) 
	{
		BankAccount b=new BankAccount();
		System.out.println("current Balance is"+b.balance);
		b.deposit(5000);
		System.out.println("current Balance is"+b.balance);
		b.deposit(-2000);
		System.out.println("current Balance is"+b.balance);
	}
}
