class Lit 
{
	public static void main(String[] args) 
	{
float a=521;//error

int b=0123F;
		System.out.println(b);
	}
}
