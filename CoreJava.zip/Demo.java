class Demo 
{
	public static void main(String[] args) 
	{
		int a=1000;
		char c=(char)a;
		System.out.println(c);
	}
}
