class Switch_withInt 
{

static void m1(int day){
	switch(day){
		case 1:
			System.out.println(day+"Today is MON");
		break;

		case 2:
			System.out.println(day+"Today is TUE");
		break;

		case 3:
			System.out.println(day+"Today is WED");
		break;

		case 4:
			System.out.println(day+"Today is THURS");
		break;

		case 5:
			System.out.println(day+"Today is FRI");
		break;

		case 6:
			System.out.println(day+"Today is SAT");
		break;

		case 7:
			System.out.println(day+"Today is SUN");
		break;

		default:
			System.out.println("Invalid option");
		    System.out.println("Enter the 0-7 option");
	}
}



	public static void main(String[] args) 
	{
		
			m1(4);//4Today is THURS

	}
}
