class A
{
	public static void main(String[] args) 
	{
		System.out.println("class A main");

		B.main(new String[2]);
	}
}
class B{
public static void main(String[] args){
System.out.println("Class B main");
}
}

