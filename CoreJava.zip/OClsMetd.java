class A 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		m1();
		B.m1();
	}
	static void m1(){
System.out.println("A\'s m1");
	}
}
class B{
static void m1(){
System.out.println("B\'s m1" );
}
}

