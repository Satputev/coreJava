class Bnk//Real world object bank account in java world 
{
	public static void main(String[] args) 
	{
		Accnt a1=new Accnt();//first object representation
		a1.Aname="hari";
		a1.Ano=20636;	
		a1.Address="hydrabad";
		a1.Balance=622554;

		Accnt a2=new Accnt();//second object representation
		a2.Aname="Ballaya";
		a2.Ano=202432;	
		a2.Address="chennai";
		a2.Balance=564292;

		System.out.println("First Account holder details...");
		System.out.println("a1.Aname: "+a1.Aname);
		System.out.println("a1.Ano: "+a1.Ano);
		System.out.println("a1.address: "+a1.Address);
		System.out.println("a1.Balance: "+a1.Balance);
		System.out.println("\n\nsecond account holder detils.....");
		System.out.println("a2.Aname: "+a2.Aname);
		System.out.println("a2.Ano: "+a2.Ano);
		System.out.println("a2.Address: "+a2.Address);
		System.out.println("a2.Balance: "+a2.Balance);
		
	}
}
