public class Transection 
{
	public static void main(String[] args) 
	{
		System.out.println("TransectionMain");
	}

static void trsDetails(){
	System.out.println("TransDetail");
}
}

 class Account{
	static void savingAccount(){
		System.out.println("SavingAccountDetail");
	}
}