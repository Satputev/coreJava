class TC 
{
	public static void main(String[] args) 
	{
		byte b=10+20;
		System.out.println(b);
		byte c=20;
		byte m=(byte)(c+b);
		System.out.println(m);
long l1=20L;
		byte bl=(byte)10L+20;
		//byte o=l1+20;
			//	byte o=byte(l1+20);

	}
}
