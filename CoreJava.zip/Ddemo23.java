class Ddemo23 
{
	public static void main(String[] args) 
	{
		char a='1';
		System.out.println(a);
	}
}
