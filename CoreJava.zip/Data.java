class Data 
{
	int i=20;
	float ff=10.3f;
	long[] lng={16L,96L};
	String s="hari";
}
