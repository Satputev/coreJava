class  Operators
{
	public static void main(String[] args) 
	{//case 1
		//a<20?"hello":"hii";
		int a=10;

		System.out.println(a<20?"hii":"hello");
		String s1=a<20?"hi":"hello";
		System.out.println(s1);

		Object o=a>20?"hi":10;//here Object is super class of all class
				System.out.println(o);
				double d=a<20?20:20.5;
						System.out.println(d);//20.0  double is super class of all numbers
		


		//Rule#2

		//String x=a<10?"hello":10;// incompatible types: bad type in conditional expression
		// int cannot be converted to String

		//int x=a<20?"hello":10;//String cannot be converted to int

//int y=(int)(a<20?"hii":10);//comlpile but but got runtime exception
//System.out.println(y);

int y;
//y=true?50:20.5;System.out.println(y);//incompatible types: possible lossy conversion from double to int
y=(int)(true?50:20.5);System.out.println(y);
//System.out.println(a+20?"hello":"hii");// int cannot be converted to boolean
//System.out.println((a<20)(a>10)?"hii":"hello");
System.out.println((a>10)&&(a>20)?"hii":"hello");//hello
System.out.println(true?35:65);
	}
}
