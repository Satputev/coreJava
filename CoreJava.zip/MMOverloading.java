class MMOverloading 
{
	public static void main(String[] args) //at that situation string arge method execute only
	{
		System.out.println("DefaultMethod");
//main(new String[5]); cannot call method inside method
main(new int[6]);
main("hii");
main(1);
	}
	public static void main(int[] args)
	{
		System.out.println("Int []");
	}
	public static void main(String a){
	System.out.println("String variable");
	}
	public static void main(int a){
	System.out.println("Int vriable");
	}
}
