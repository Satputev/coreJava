class Student //data class
{
String sname;
int sRollno;
String Course;
int Cfees;
}
