class PrintNameSep{

	public static void main(String[]args){

	System.out.print("Hari\nKrushna");
	}

}