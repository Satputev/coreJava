class SwitchString 
{

static void dayName(char num){
	switch(num){
		case "1":
			System.out.println(num+"/tday is MON");
		break;

		case "2":
			System.out.println(num+"/t day is TUE");
		break;

		case "3":
			System.out.println(num +"/t day is WED");
		break;

		case "4":
			System.out.println(num+"/t day is THU");
		break;

		case "5":
			System.out.println(num+"/t day is FRI");
		break;

		case "6":
			System.out.println(num +"/t day is SAT");
		break;

		case "7":
			System.out.println(num+"/t day is SUN");
		break;

		default:
			System.out.println("INVALID OPTION");

	}
}
	public static void main(String[] args) 
	{
		dayName('5');
	}
}
