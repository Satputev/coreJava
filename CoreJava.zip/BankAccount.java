class BankAccount 
{
	double balance;
	void deposit(double amt){
	if(amt>0)
	balance +=amt;
	}
}
