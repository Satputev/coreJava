class Literals 
{
	public static void main(String[] args) 
	{

		Integer a=null;
		String s=null;
		// Studt st=null;    it is not a class or array or inerface 0r enum or annotation
		System.out.println(a);
		System.out.println(s);
		//System.out.println(st);
	//	boolean b=null;//incompatible types: <null> cannot be converted to boolean
               // boolean b=null;
		/** null do not have any specific type it is of referenced type*/
		System.out.println(10);
		//System.out.println(12b);
		System.out.println(15L);
		//System.out.println(78s);
		System.out.println(12.5);
		System.out.println(12.5f);
		System.out.println('h');
		System.out.println(true);
	//	System.out.println(null);/*reference to println is ambiguous//System.out.println(null)
		// both method println(char[]) in PrintStream and method println(String) in PrintStream match*/
		
		System.out.println("hello");
		System.out.println(String.class);
		System.out.println(int.class);
		System.out.println(float.class);
		System.out.println(char.class);
		System.out.println(boolean.class);
		System.out.println(int[].class);
		System.out.println(Student.class);
		System.out.println(Integer.class);

		System.out.println(System.class);
char[] ca=null;//compiletime no error :except char all other datatypes executes successfully...
//System.out.println(ca);//java.lang.NullPointerException
//use literals only in 
//1.variable assignment
//2.in an expression
//3.as a method arg

//eg.

//10
//10;
//10=10
int m=10;
int n=m+20;
System.out.println(10);

System.out.println(0XA1);//161(hexadecimal)
System.out.println(0B10100);//20 (binary)
System.out.println(012);//10 (octal)


	}
}
