class Employee //data type class
{
	int eid;
	String ename;
	String dept;
	double esal;
}
