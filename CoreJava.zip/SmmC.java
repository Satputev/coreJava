class A 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}

static void m1(){
System.out.println("A m1");
	}

}

class B
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
static void m1(){
System.out.println("B m1");
	}

}



class C
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
	static void m1(){
System.out.println("C m1");
	}

}


class D 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
	static void m1(){
System.out.println("D m1");
	}

}

class E
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
A.m1();
B.m1();
C.m1();
D.m1();
m1();


	}
	static void m1(){
System.out.println("E m1");
	}

}
