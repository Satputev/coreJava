class DT 
{
	public static void main(String[] args) 
	{

	int a=100;
	float f=12.6f;
	double d=123.6;
	char ch='h';
	boolean bo=false;
	System.out.println(a);
	System.out.println(f);
	System.out.println(d);
	System.out.println(ch);
	System.out.println(bo);

	int[] arr={5,10,20,30};
	double[] db={21.2,32.2,10.3};

	System.out.println(arr[0]);
	System.out.println(arr[1]);
	System.out.println(arr[2]);
	System.out.println(db[0]);
	System.out.println(db[1]);
	System.out.println(db[2]);
Data dta=new Data();
	System.out.println(dta.i);
	System.out.println(dta.ff);
	System.out.println(dta.lng);
	System.out.println(dta.s);
	System.out.println(dta.lng[0]);
	System.out.println(dta.lng[1]);
	


	}
}
