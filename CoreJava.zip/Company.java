class Company 
{
	public static void main(String[] args) 
	{
	System.out.println("project for company maintaining employee details....");
	Employee e1=new Employee();//first employee object
	e1.eid=101;
	e1.ename="hari";
	e1.dept="Java";
	e1.esal=8566155.36;
	
	Employee e2=new Employee();//second employee object
	e2.eid=105;
	e2.ename="Ravi";
	e2.dept="python";
	e2.esal=9545454.65;
	//Displaying e1 and e2 objects values..
	System.out.println("e1 pointing objects values..");
	System.out.println("e1.id: "+e1.eid);
	System.out.println("e1.ename: "+e1.ename);
	System.out.println("e1.dept: "+e1.dept);
	System.out.println("e1.esal: "+e1.esal);

	System.out.println("e2 pointing objects values..");
	System.out.println("e2.id: "+e2.eid);
	System.out.println("e2.ename: "+e2.ename);
	System.out.println("e2.dept: "+e2.dept);
	System.out.println("e2.esal: "+e2.esal);


	}
}
