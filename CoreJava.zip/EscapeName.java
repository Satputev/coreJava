class EscapeName 
{
	public static void main(String[] args) 
	{
		System.out.println("\"Hari\"");
		System.out.println("\'Hari\'");
		System.out.println("\\Hari\\");
		System.out.println("Hari\b");
		System.out.println("Ha\rri");
		System.out.println("\fHari");

	}
}
