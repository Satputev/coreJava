class Institute //build the project for Institute
{
	public static void main(String[] args) 
	{
		Student s1=new Student();
		s1.sname="HK";
		s1.sRollno=120;
		s1.Course="core java";
		s1.Cfees=1500;

		Student s2=new Student();
		s2.sname="BK";
		s2.sRollno=121;
		s2.Course="Acting";
		s2.Cfees=5000;

		System.out.println("1st object values.... ");
		System.out.println("s1.sname: "+s1.sname);
		System.out.println("s1.sRollno: "+s1.sRollno);
		System.out.println("s1.Course: "+s1.Course);
		System.out.println("s1.Cfee: "+s1.Cfees);

		System.out.println("2nd object values.... ");
		System.out.println("s2.sname: "+s2.sname);
		System.out.println("s2.sRollno: "+s2.sRollno);
		System.out.println("s2.Course: "+s2.Course);
		System.out.println("s2.Cfee: "+s2.Cfees);

	}
}
