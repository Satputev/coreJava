class Recursive 
{
	static void m1(){
System.out.println("No argument method");

	}
	static void m1(int a){
	System.out.println("One argumet");
	}
	public static void main(String[] args) 
	{
m1();
	}
}
