class Variable 
{
	public static void main(String[] args) 
	{
		System.out.println(5555555555L);

//byte variable byte bb=5; 1
m1((byte)5);  
//a=5b;
int a=(int)55555555554454L;
m1(a);
	}
	static void m1(int b){
	System.out.println(b);
	}
}
