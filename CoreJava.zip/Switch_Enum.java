
enum Day{
MON,TUE,WED,THU,FRI,SAT,SUN

}

class Switch_Enum 
{

static void displayDayName(Day day){
	switch(day){
		case MON:
			System.out.println(day+"is 1 in Week");
		break;

		case TUE:
			System.out.println(day+ "is 2 in week");
		break;

		case WED:
			System.out.println(day +"is 3 in week");
		break;

		case THU:
			System.out.println(day +"is 4 in week");
		break;

		case FRI:
			System.out.println(day +"is 5 in week");
		break;

		case SAT:
			System.out.println(day+ "is 6 in week");
		break;

		case SUN:
			System.out.println(day+" is 7 inweek");
		break;

		default:
			System.out.println("Invalid option");
			System.out.println("Choose 0-7");
	}

}


	public static void main(String[] args) 
	{
displayDayName(Day.MON);//MONis 1 in Week
//displayDayName(10);//int cannot be converted to Day
	
	}
}
