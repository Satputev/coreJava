class MethodOverloading 
{

static void a(){
System.out.println("No argument");

}
static void a(int c,int m){
System.out.println("One int argument");	
}
 static int a(int n){
System.out.println("Two int argument");	
return 0;
}
static void a(int m,double n){
System.out.println("1 int 1 double argument");	

}
static void a(float m,int n){
System.out.println("1 float 1 int argument");	

}
static void a(double m,int n){
System.out.println("1 double 1 int argument");	

}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		a(5);
main("hhhhhh");
	}
	static void main(String a) 
	{
		System.out.println("ffffffdss");
		

	}
}
