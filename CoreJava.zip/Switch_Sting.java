class Switch_Sting 
{   
	
	static void display_Day(String day){
		switch (day)
		{
		case "MON":
			System.out.println(day +"is 1 in week");
		break;
		case "TUE":
			System.out.println(day+ "is 2 in week");
		break;
		case "WED":
			System.out.println(day +"is 3 in week");
		break;

		case "THU":
			System.out.println(day +"is  4 in week");
		break;

		case "FRI":
			System.out.println(day +"is 5 in week");
		break;

		case "SAT":
			System.out.println(day +"is 6 in week");
		break;

		case "SUN":
			System.out.println(day +"is 7 in week");
		break;

		default:
			System.out.println("Invalid option ");
			System.out.println("select valid option");

		
		}
	}

	public static void main(String[] args) 
	{
		display_Day("TUE");//TUEis 2 in week

		display_Day("hk");//Invalid option
//select valid option
	}
}
