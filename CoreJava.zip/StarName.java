class StarName{
	public static void main(String[] args) {
		System.out.println("************");	
		System.out.println("*Hari Krushna*");	
		System.out.println("************");
	}
}
