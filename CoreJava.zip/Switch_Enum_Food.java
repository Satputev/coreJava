enum Tiffin {
	IDELY,DOSA,PURI
}


class Switch_Enum_Food 
{


static void get_Price(Tiffin food){
	switch(food){
		case IDELY:
			System.out.println(food +" Price is 30/-");
		break;

		case DOSA:
			System.out.println(food +"price is 40/-");
		break;

		case PURI:
			System.out.println(food+"Price is 50/-");

	}
}



	public static void main(String[] args) 
	{
		
		get_Price(Tiffin.DOSA);//DOSAprice is 40/-
		//get_Price(Tiffin.Puri);// cannot find symbol   get_Price(Tiffin.Puri);
		get_Price(Tiffin.PURI);//PURIPrice is 50/-
               

	}
}
